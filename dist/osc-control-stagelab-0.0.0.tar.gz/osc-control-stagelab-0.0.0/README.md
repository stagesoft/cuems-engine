add path to settings.xml
----
run ossia_server.py
